-- phpMyAdmin SQL Dump
-- version 4.0.9
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Апр 18 2014 г., 16:14
-- Версия сервера: 5.6.14-log
-- Версия PHP: 5.5.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `applegcm`
--
CREATE DATABASE IF NOT EXISTS `applegcm` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `applegcm`;

-- --------------------------------------------------------

--
-- Структура таблицы `authassignment`
--

DROP TABLE IF EXISTS `authassignment`;
CREATE TABLE IF NOT EXISTS `authassignment` (
  `itemname` varchar(64) NOT NULL,
  `userid` varchar(64) NOT NULL,
  `bizrule` text,
  `data` text,
  PRIMARY KEY (`itemname`,`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=cp1251;

--
-- Дамп данных таблицы `authassignment`
--

INSERT INTO `authassignment` (`itemname`, `userid`, `bizrule`, `data`) VALUES
('Administrator', '1', NULL, NULL),
('Administrator', '6', '', 's:0:"";'),
('Authority', '7', NULL, NULL),
('User', '11', NULL, NULL),
('User', '12', NULL, NULL),
('User', '13', NULL, NULL),
('User', '14', NULL, NULL),
('User', '5', NULL, NULL),
('User', '8', '', 's:0:"";'),
('User', '9', NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `authitem`
--

DROP TABLE IF EXISTS `authitem`;
CREATE TABLE IF NOT EXISTS `authitem` (
  `name` varchar(64) NOT NULL,
  `type` int(11) NOT NULL,
  `description` text,
  `bizrule` text,
  `data` text,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=cp1251;

--
-- Дамп данных таблицы `authitem`
--

INSERT INTO `authitem` (`name`, `type`, `description`, `bizrule`, `data`) VALUES
('Administrator', 2, NULL, NULL, NULL),
('ChangeOrderContent', 0, NULL, NULL, NULL),
('Create Post', 0, NULL, NULL, NULL),
('Create User', 0, NULL, NULL, NULL),
('Create_Roles', 0, NULL, NULL, NULL),
('Delete Post', 0, NULL, NULL, NULL),
('Delete User', 0, NULL, NULL, NULL),
('Edit Documents', 0, NULL, NULL, NULL),
('Edit Post', 0, NULL, NULL, NULL),
('Edit User', 0, NULL, NULL, NULL),
('file_reader', 0, NULL, NULL, NULL),
('file_save', 0, NULL, NULL, NULL),
('ManageOrders', 1, NULL, NULL, NULL),
('Post Manager', 1, NULL, NULL, NULL),
('Store Manager', 1, NULL, NULL, NULL),
('User', 2, NULL, NULL, NULL),
('User Manager', 1, NULL, NULL, NULL),
('View Post', 0, NULL, NULL, NULL),
('View User', 0, NULL, NULL, NULL),
('ViewOrders', 0, NULL, NULL, NULL),
('Заказ товаров', 0, NULL, NULL, NULL),
('Изменение прайслистов', 0, NULL, NULL, NULL),
('Каталог товаров', 1, NULL, NULL, NULL),
('Меню', 1, NULL, NULL, NULL),
('Правка товаров', 0, NULL, NULL, NULL),
('Правка_меню', 0, NULL, NULL, NULL),
('Управление файлами', 1, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `authitemchild`
--

DROP TABLE IF EXISTS `authitemchild`;
CREATE TABLE IF NOT EXISTS `authitemchild` (
  `parent` varchar(64) NOT NULL,
  `child` varchar(64) NOT NULL,
  PRIMARY KEY (`parent`,`child`),
  KEY `child` (`child`)
) ENGINE=InnoDB DEFAULT CHARSET=cp1251;

--
-- Дамп данных таблицы `authitemchild`
--

INSERT INTO `authitemchild` (`parent`, `child`) VALUES
('ManageOrders', 'ChangeOrderContent'),
('Post Manager', 'Create Post'),
('User Manager', 'Create User'),
('User Manager', 'Create_Roles'),
('User Manager', 'Delete User'),
('Store Manager', 'Edit Documents'),
('Post Manager', 'Edit Post'),
('User Manager', 'Edit User'),
('User', 'file_reader'),
('Управление файлами', 'file_reader'),
('Управление файлами', 'file_save'),
('Administrator', 'ManageOrders'),
('Administrator', 'Post Manager'),
('Administrator', 'Store Manager'),
('Administrator', 'User Manager'),
('Post Manager', 'View Post'),
('User', 'View Post'),
('ManageOrders', 'ViewOrders'),
('User', 'Заказ товаров'),
('Каталог товаров', 'Заказ товаров'),
('Каталог товаров', 'Изменение прайслистов'),
('Administrator', 'Каталог товаров'),
('Administrator', 'Меню'),
('Каталог товаров', 'Правка товаров'),
('Меню', 'Правка_меню'),
('Administrator', 'Управление файлами');

-- --------------------------------------------------------

--
-- Структура таблицы `clients`
--

DROP TABLE IF EXISTS `clients`;
CREATE TABLE IF NOT EXISTS `clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(25) NOT NULL DEFAULT '0',
  `first_name` varchar(100) DEFAULT NULL,
  `second_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `client_email` varchar(100) DEFAULT NULL,
  `client_password` varchar(100) DEFAULT NULL,
  `client_tels` varchar(150) DEFAULT NULL,
  `client_post_index` varchar(10) DEFAULT NULL,
  `client_country` varchar(50) DEFAULT NULL,
  `client_oblast` varchar(100) DEFAULT NULL,
  `client_district` varchar(100) DEFAULT NULL,
  `client_city` varchar(100) DEFAULT NULL,
  `client_street` varchar(150) DEFAULT NULL,
  `client_house` varchar(10) DEFAULT NULL,
  `client_korpus` varchar(10) DEFAULT NULL,
  `client_stroenie` varchar(10) DEFAULT NULL,
  `client_apart` varchar(10) DEFAULT NULL,
  `client_flore` varchar(10) DEFAULT NULL,
  `client_code` varchar(25) DEFAULT NULL,
  `client_entrance` varchar(25) DEFAULT NULL,
  `client_comments` varchar(255) DEFAULT NULL,
  `client_vip` tinyint(4) NOT NULL DEFAULT '0',
  `client_metro` varchar(100) DEFAULT NULL,
  `client_fax` varchar(100) DEFAULT NULL,
  `urlico` int(11) NOT NULL DEFAULT '0',
  `urlico_txt` varchar(512) DEFAULT NULL,
  `type` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0-клиент, 1 - группа',
  `parent` int(11) NOT NULL DEFAULT '0' COMMENT 'родительская группа',
  `sort_group` smallint(6) NOT NULL DEFAULT '0' COMMENT 'сортировка',
  `group_belong` smallint(6) NOT NULL DEFAULT '119' COMMENT 'Группа',
  `client_passport` varchar(255) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Информация о клиентах' AUTO_INCREMENT=272 ;

--
-- Дамп данных таблицы `clients`
--

INSERT INTO `clients` (`id`, `login`, `first_name`, `second_name`, `last_name`, `client_email`, `client_password`, `client_tels`, `client_post_index`, `client_country`, `client_oblast`, `client_district`, `client_city`, `client_street`, `client_house`, `client_korpus`, `client_stroenie`, `client_apart`, `client_flore`, `client_code`, `client_entrance`, `client_comments`, `client_vip`, `client_metro`, `client_fax`, `urlico`, `urlico_txt`, `type`, `parent`, `sort_group`, `group_belong`, `client_passport`, `status`) VALUES
(1, 'Tick007@yandex.ru', 'Василий', 'Пупкин ooipo', 'Олегович 23', 'Tick007@yandex.ru', '1234As5678', '89067456278', '700114', '', '', '', 'Москва ', 'Лестева 23', '19 23', '2 23', '1 23', '123 23', '5 23', '919123', '223', 'ййй 23 456546', 0, 'wer 23', '', 0, NULL, 0, 0, 0, 123, 'Паспорт 2804 261282', 0),
(2, '9', NULL, NULL, NULL, '9', '9', '', NULL, NULL, NULL, NULL, 'Москва', '123', '123', '123', '123', '123', '132', '', '', 'wrere', 0, '', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(3, '9', 'VVS', '', '', '9', '9', '2', NULL, NULL, NULL, NULL, '', '2', '2', '2', '2', '2', '2', '2', '2', '2', 0, '2', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(4, '9', 'Игорь', 'ПУПКИН2', '', '9', '9', '9', NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', '', '', '', 0, '', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(17, 'T@r.ru', '', '', '', 'T@r.ru', '17', '1', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(18, 'Tick007@yandex.ru', '64', '64456', '', 'Tick007@yandex.ru', '18', '1', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(19, 'Tick007@yandex.ru', 'wqe', 'qwe', '', 'Tick007@yandex.ru', '19', '1qwe', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(20, 'Tick007@yandex.ru', 'asd', 'asd', '', 'Tick007@yandex.ru', '20', 'asd', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(21, 'Tick007@yandex.ru', '123', '123', '', 'Tick007@yandex.ru', '21', '123', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(22, '22', '', '', '', '22', '22', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(23, '23', '', '', '', '23', '23', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(24, '24', '', '', '', '24', '24', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(25, '25', '', '', '', '25', '25', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(26, '26', '', '', '', '26', '26', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(27, '27', '', '', '', '27', '27', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(28, '28', '', '', '', '28', '28', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(29, '29', '', '', '', '29', '29', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(30, '30', '', '', '', '30', '30', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(31, '31', '', '', '', '31', '31', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(32, '32', '', '', '', '32', '32', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(33, '33', '', '', '', '33', '33', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(34, '34', '', '', '', '34', '34', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(35, '35', '', '', '', '35', '35', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(36, '36', '', '', '', '36', '36', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(37, '37', '', '', '', '37', '37', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(38, '38', '', '', '', '38', '38', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(39, '39', '', '', '', '39', '39', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(40, '40', '', '', '', '40', '40', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(41, '41', '', '', '', '41', '41', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(42, '42', '', '', '', '42', '42', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(43, '43', '', '', '', '43', '43', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(44, '44', '', '', '', '44', '44', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(45, '45', '', '', '', '45', '45', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(46, '46', '', '', '', '46', '46', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(47, '47', '', '', '', '47', '47', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(48, '48', '', '', '', '48', '48', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(49, '49', '', '', '', '49', '49', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(50, '50', '', '', '', '50', '50', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(51, '51', '', '', '', '51', '51', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(52, '52', '', '', '', '52', '52', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(53, '53', '', '', '', '53', '53', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(54, '54', '', '', '', '54', '54', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(55, '55', '', '', '', '55', '55', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(56, '56', '', '', '', '56', '56', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(57, '57', '', '', '', '57', '57', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(58, '58', '', '', '', '58', '58', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(59, '59', '', '', '', '59', '59', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(60, '60', '', '', '', '60', '60', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(61, '61', '', '', '', '61', '61', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(62, '62', '', '', '', '62', '62', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(63, '63', '', '', '', '63', '63', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(64, '64', '', '', '', '64', '64', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(65, '65', '', '', '', '65', '65', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(66, 'Tick007@yandex.ru', 'qqq', 'qqq', '', 'Tick007@yandex.ru', '66', 'qqq', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(67, '67', '', '', '', '67', '67', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(68, 'Tick007@yandex.ru', 'Игорь', 'Иванов', '', 'Tick007@yandex.ru', '68', '1231132132', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(69, 'Tick007@yandex.ru', 'Игорь', 'Иванов', '', 'Tick007@yandex.ru', '69', '213213', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(70, 'Tick007@yandex.ru', 'Иванов', 'Игорь', '', 'Tick007@yandex.ru', '70', '134123', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', '', 31131, NULL, 0, 0, 0, 121, NULL, 0),
(71, 'Tick007@yandex.ru', 'wer', '4242', '', 'Tick007@yandex.ru', '71', '46456', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(72, 'Tick007@yandex.ru', 'Василий', 'Пупкин', '', 'Tick007@yandex.ru', '72', 'цйукцйук', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(73, 'Tick007@yandex.ru', 'Игорь', 'Иванов', '', 'Tick007@yandex.ru', '73', '', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(74, 'Tick007@yandex.ru', 'Иванов', 'Игорь', '', 'Tick007@yandex.ru', '74', '3213', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', '', 312, NULL, 0, 0, 0, 119, NULL, 0),
(75, 'Tick007@yandex.ru', 'asdad', 'dasD', '', 'Tick007@yandex.ru', '75', '', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(76, 'Tick007@rol.ru', '21', '12', 'wqeqwe', 'Tick007@rol.ru', '76', '23423423', '', '', '', '', 'Moscower', 'Strwer', 'Domwer', 'Korprew', 'Stroenwer', '4', '3', '2', '1', '46546456', 0, 'Metrower', '23423fsdsdf', 0, NULL, 0, 0, 0, 119, NULL, 0),
(77, 'info1@warehouse-soft.ru', 'Игорь', 'Иванов', '', 'info1@warehouse-soft.ru', '77', 'ываыв', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(78, 'info1@warehouse-soft.ru', 'qwe', 'wqe', '', 'info1@warehouse-soft.ru', '78', '', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(79, 'info1@warehouse-soft.ru', 'eeee', 'eeee', '', 'info1@warehouse-soft.ru', '79', 'ee', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(80, 'Tick007@yandex.ru', 'fdgfd', 'dgdfg', '', 'Tick007@yandex.ru', '80', 'dgdfg', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(81, 'Tick007@yandex.ru', 'fdsfsd', 'sdfsdf', '', 'Tick007@yandex.ru', '81', 'sfsdf', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(82, 'info1@warehouse-soft.ruw', 'weqqe', 'ewq', '', 'info1@warehouse-soft.ruw', '82', 'w', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(83, 'Tick007@yandex.ru', '23423', '234', '', 'Tick007@yandex.ru', '83', '2342', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(84, 'info1@warehouse-soft.ru', 'werwe', 'rwerwer', '', 'info1@warehouse-soft.ru', '84', 'werew', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(85, 'Tick007@yandex.ru', 'qweqw', 'eqwe', '', 'Tick007@yandex.ru', '85', 'qweqw', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(86, '86', '', '', '', '86', '86', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'CommentsРё', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(87, 'Tick0987@rol.ru', 'Tick0987@rol.ru', 'Tick0987@rol.ru', '', 'Tick0987@rol.ru', '87', 'Tick0987@rol.ru', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(88, 'Tick007@yandex.ru', 'Tick007@yandex.ru', 'Tick007@yandex.ru', '', 'Tick007@yandex.ru', '88', 'Tick007@yandex.ru', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(89, 'Tick0987@rol.ru', 'Tick0987@rol.ru', 'Tick0987@rol.ru', '', 'Tick0987@rol.ru', '89', 'Tick0987@rol.ru', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(90, 'Tick0987@rol.ru', 'Tick0987@rol.ru', 'Tick0987@rol.ru', '', 'Tick0987@rol.ru', '90', 'Tick0987@rol.ru', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(91, 'info1@warehouse-soft.ru', 'info1@warehouse-soft.ru', 'info1@warehouse-soft.ru', '', 'info1@warehouse-soft.ru', '91', 'info1@warehouse-soft.ru', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(92, 'Tick007@yandex.ru', 'Tick007@yandex.ru', 'Tick007@yandex.ru', '', 'Tick007@yandex.ru', '92', 'Tick007@yandex.ru', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(93, 'info1@warehouse-soft.ru', 'info1@warehouse-soft.ru', 'info1@warehouse-soft.ru', '', 'info1@warehouse-soft.ru', '93', 'info1@warehouse-soft.ru', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(94, 'info2@warehouse-soft.ru', '', '', '', 'info2@warehouse-soft.ru', '1', '', NULL, NULL, NULL, NULL, 'Москва', '', '', '', '', '', '', '', '', '', 0, '', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(95, 'info3@warehouse-soft.ru', '', '', '', 'info3@warehouse-soft.ru', '3', '', NULL, NULL, NULL, NULL, 'Москва', '', '', '', '', '', '', '', '', '', 0, '', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(96, '96', '', '', '', '96', '96', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(97, '97', '', '', '', '97', '97', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(98, '98', '', '', '', '98', '98', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(99, '99', '', '', '', '99', '99', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(100, '100', '', '', '', '100', '100', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(101, '101', '', '', '', '101', '101', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(102, '102', '', '', '', '102', '102', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(103, '103', '', '', '', '103', '103', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(104, '104', '', '', '', '104', '104', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(105, '105', '', '', '', '105', '105', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(106, '106', '', '', '', '106', '106', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(107, 'Tick007@rol.ru', 'Tick007@rol.ru', 'Tick007@rol.ru', '', 'Tick007@rol.ru', '107', 'Tick007@rol.ru', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(108, 'Tick007@rol.ru', 'Tick007@rol.ru', 'Tick007@rol.ru', '', 'Tick007@rol.ru', '108', 'Tick007@rol.ru', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(109, 'Tick007@rol.ru', 'Tick007@rol.ru', 'Tick007@rol.ru', '', 'Tick007@rol.ru', '109', 'Tick007@rol.ru', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(110, 'Tick007@yandex.ru', 'Tick007@yandex.ru', 'Tick007@yandex.ru', '', 'Tick007@yandex.ru', '110', 'Tick007@yandex.ru', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(111, 'Tick007@yandex.ru', 'Tick007@yandex.ru', 'Tick007@yandex.ru', '', 'Tick007@yandex.ru', '111', 'Tick007@yandex.ru', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(112, 'Tick@tre.ru', 'Tick@tre.ru', 'Tick@tre.ru', '', 'Tick@tre.ru', '112', 'Tick@tre.ru', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(113, 'Ttt@rol.ru', 'Ttt@rol.ru', 'Ttt@rol.ru', '', 'Ttt@rol.ru', '113', 'Ttt@rol.ru', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(114, 'Ttt@rol.ru', 'Ttt@rol.ru', 'Ttt@rol.ru', '', 'Ttt@rol.ru', '114', 'Ttt@rol.ru', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(115, 'Tick007@yahoo.com', 'Tick007@yahoo.com', 'Tick007@yahoo.com', '', 'Tick007@yahoo.com', '115', 'Tick007@yahoo.com', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(116, 'Tick007@yahoo.com', 'Tick007@yahoo.com', 'Tick007@yahoo.com', '', 'Tick007@yahoo.com', '116', 'Tick007@yahoo.com', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(117, 'Tick007@yahoo.com', 'Tick007@yahoo.com', 'Tick007@yahoo.com', '', 'Tick007@yahoo.com', '117', 'Tick007@yahoo.com', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(118, 'Tick007@rol.ru', 'Tick007@rol.ru', 'Tick007@rol.ru', '', 'Tick007@rol.ru', '118', 'Tick007@rol.ru', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(119, '', 'Общая', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, 1, 0, 0, 0, NULL, 0),
(120, '', 'Постоянные', '', '', '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', 0, NULL, 1, 0, 0, 0, NULL, 0),
(121, '', 'Москва', '', '', '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', 0, NULL, 1, 119, 1, 0, NULL, 0),
(122, '', 'Питер', '', '', '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', 0, NULL, 1, 119, 0, 0, NULL, 0),
(123, '', 'Область', '', '', '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', 0, NULL, 1, 119, 0, 120, NULL, 0),
(124, '', 'Новая группа', '', '', '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', 0, NULL, 1, 120, 0, 119, NULL, 0),
(125, '', '', '', '', '125', '125', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(126, '', 'qweqwe', 'qweqwe', '', 'Tick007@yandex.ru', '126', 'qwe', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(127, '', '', '', '', '127', '127', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(128, '', 'info@warehouse-soft.ru', 'info@warehouse-soft.ru', '', 'info@warehouse-soft.ru', '128', 'info@warehouse-soft.ru', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(129, '', 'tick007@yandex.ru', 'tick007@yandex.ru', '', 'tick007@yandex.ru', '129', 'tick007@yandex.ru', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(130, '', '', '', '', '130', '130', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(131, '', 'Игорь', 'Иванов', '', 'Tick007@yandex.ru', '131', '09324809234', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(132, '', 'ewerewr', 'zxvczxcvzcx', '', 'info1@warehouse-soft.ru', '132', '254252543', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(133, '', 'qweqwe', '231312', '', 'Ti@lkfewe.ru', '133', 'wewqeq', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(134, '', 'wqe', '31231', '', 'Tick007@yandex.ru', '134', 'adfs432', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(135, '', '', '', '', '135', '135', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(136, '', 'Tick007@yandex.ru', 'Tick007@yandex.ru', '', 'Tick007@yandex.ru', '136', 'Tick007@yandex.ru', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(137, '', 'Tick007@yandex.ru', 'Tick007@yandex.ru', '', 'Tick007@yandex.ru', '137', 'Tick007@yandex.ru', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(138, '', 'Tick007@yandex.ru', 'Tick007@yandex.ru', '', 'Tick007@yandex.ru', '138', 'Tick007@yandex.ru', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(139, '', '', '', '', '139', '139', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(140, '', 'qwe', 'qwe', '', 'info1@warehouse-soft.ru', '140', 'qweq', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(141, '', 'qwew', '', '', 'info@warehouse.ru', '141', '', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(142, '', '', '', '', '142', '142', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(143, '', '', '', '', '143', '143', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(144, '', '', '', '', '144', '144', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(145, '', '', '', '', '145', '145', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(146, '', '', '', '', '146', '146', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(147, '', '', '', '', '147', '147', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(148, '', '', '', '', '148', '148', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(149, '', '', '', '', '149', '149', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(150, '', '', '', '', '150', '150', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(151, '', '', '', '', '151', '151', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(152, '', '', '', '', '152', '152', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(153, '', '', '', '', '153', '153', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(154, '', '', '', '', '154', '154', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(155, '', '', '', '', '155', '155', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(156, '', '', '', '', '156', '156', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(157, '', '', '', '', '157', '157', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(158, '', '', '', '', '158', '158', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(159, '', '', '', '', '159', '159', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(160, '', '', '', '', '160', '160', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(161, '', '', '', '', '161', '161', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(162, '', '', '', '', '162', '162', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(163, '', '', '', '', '163', '163', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(164, '', '', '', '', '164', '164', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(165, '', '', '', '', '165', '165', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(166, '', '', '', '', '166', '166', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(167, '', '', '', '', '167', '167', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(168, '', '', '', '', '168', '168', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(169, '', '', '', '', '169', '169', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(170, '', '', '', '', '170', '170', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(171, '', '', '', '', '171', '171', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(172, '', '', '', '', '172', '172', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(173, '', '', '', '', '173', '173', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(174, '', '', '', '', '174', '174', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(175, '', '', '', '', '175', '175', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(176, '', '', '', '', '176', '176', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(177, '', '', '', '', '177', '177', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(178, '', '', '', '', '178', '178', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(179, '', '', '', '', '179', '179', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(180, '', '', '', '', '180', '180', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(181, '', '', '', '', '181', '181', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(182, '', '', '', '', '182', '182', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(183, '', '', '', '', '183', '183', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(184, '', '', '', '', '184', '184', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(185, '', '', '', '', '185', '185', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(186, '', '', '', '', '186', '186', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(187, '', '', '', '', '187', '187', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(188, '', '', '', '', '188', '188', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(189, '', '', '', '', '189', '189', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(190, '', '', '', '', '190', '190', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(191, '', '', '', '', '191', '191', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(192, '', '', '', '', '192', '192', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(193, '', '', '', '', '193', '193', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(194, '', '', '', '', '194', '194', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(195, '', '', '', '', '195', '195', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(196, '', '', '', '', '196', '196', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(197, '', '', '', '', '197', '197', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(198, '', '', '', '', '198', '198', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(199, '', '', '', '', '199', '199', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(200, '', '', '', '', '200', '200', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(201, '', '', '', '', '201', '201', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(202, '', '', '', '', '202', '202', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(203, '', '', '', '', '203', '203', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(204, '', '', '', '', '204', '204', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(205, '', '', '', '', '205', '205', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(206, '', '', '', '', '206', '206', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(207, '', '', '', '', '207', '207', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(208, '', '', '', '', '208', '208', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(209, '', '', '', '', '209', '209', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(210, '', '', '', '', '210', '210', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(211, '', '', '', '', '211', '211', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(212, '', '', '', '', '212', '212', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(213, '', '', '', '', '213', '213', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(214, '', '', '', '', '214', '214', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(215, '', '', '', '', '215', '215', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(216, '', '', '', '', '216', '216', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(217, '', '', '', '', '217', '217', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(218, '', 'wqe', 'qwe', '', 'info32@yandex.ru', '218', 'wqe', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(219, '', 'qwe', 'qwe', '', 'Tick@00.ru', '219', 'qwe', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(220, '', '213', '123', '', 'ya@ya.ru', '220', '123', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(221, '', '234', '234', '', 'dfdf@wert.ru', '221', '234', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, NULL, 0),
(222, '', 'qwe', 'qwe', '', 'ds@ya.ru', '222', 'qwe', '', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, '', 0),
(223, '', 'qweq', 'qwe', '', 'ret@ya.ru', '223', 'qweqwe', '111111', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, '111111', 0),
(224, '', '', '', '', '224', '224', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(225, '', '', '', '', '225', '225', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(226, '', '', '', '', '226', '226', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(227, '', '', '', '', '227', '227', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(228, '', '', '', '', '228', '228', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(229, '', '', '', '', '229', '229', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(230, '', '', '', '', '230', '230', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(231, '', 'Мега', 'Хрюн', '', 'hrun@yandex.ru', '12345678', '', NULL, NULL, NULL, NULL, 'Москва', '', '', '', '', '', '', '', '', '', 0, '', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(232, '', '', '', '', '232', '232', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(233, '', '', '', '', '233', '233', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(234, '', '', '', '', '234', '234', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(235, '', '', '', '', '235', '235', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(236, '', '', '', '', '236', '236', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(237, '', '', '', '', '237', '237', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(238, '', '', '', '', '238', '238', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(239, '', '', '', '', '239', '239', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(240, '', '', '', '', '240', '240', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(241, '', '', '', '', '241', '241', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(242, '', '', '', '', '242', '242', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(243, '', '', '', '', '243', '243', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0);
INSERT INTO `clients` (`id`, `login`, `first_name`, `second_name`, `last_name`, `client_email`, `client_password`, `client_tels`, `client_post_index`, `client_country`, `client_oblast`, `client_district`, `client_city`, `client_street`, `client_house`, `client_korpus`, `client_stroenie`, `client_apart`, `client_flore`, `client_code`, `client_entrance`, `client_comments`, `client_vip`, `client_metro`, `client_fax`, `urlico`, `urlico_txt`, `type`, `parent`, `sort_group`, `group_belong`, `client_passport`, `status`) VALUES
(244, '', '', '', '', '244', '244', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(245, '', '', '', '', '245', '245', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(246, '', '', '', '', '246', '246', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(247, '', '', '', '', '247', '247', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(248, '', '', '', '', '248', '248', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(249, '', '', '', '', '249', '249', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(250, '', '', '', '', '250', '250', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(251, '', '', '', '', '251', '251', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(252, '', '', '', '', '252', '252', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(253, '', '', '', '', '253', '253', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(254, '', '', '', '', '254', '254', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(255, '', '', '', '', '255', '255', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(256, '', '', '', '', '256', '256', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(257, '', '', '', '', '257', '257', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(258, '', '', '', '', '258', '258', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(259, '', '', '', '', '259', '259', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(260, '', '', '', '', '260', '260', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(261, '', '', '', '', '261', '261', '1', NULL, NULL, NULL, NULL, 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(262, '', 'qwe', 'qwe', '', 'Tick007@yandex.ru', '262', 'qwe', 'qwe', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, 'qwe', 0),
(263, '', 'wqe', 'qew', '', 'tICK007@ya.ru', '263', 'qwe', 'qwe', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, 'qwe', 0),
(264, '', 'dsffds', 'dsfg', '', 'Tick007@ya.ru', '264', 'dsg', 'sdg', '', '', '', 'Moscow', 'Str', 'Dom', 'Korp', 'Stroen', 'Kvart', 'Etaj', 'code', 'Podezd', 'Comments', 0, 'Metro', '', 0, NULL, 0, 0, 0, 119, 'dfs', 0),
(265, '', NULL, NULL, NULL, '265', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(266, '266', '2352345', '3245234', NULL, 'Tick007@yandex.ru', NULL, '53245', '3245', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, 0, 0, 0, 119, '3425324', 0),
(267, '267', 'Шапик', 'Шапиков', NULL, 'igor.ivanov@novline.com', NULL, '12345678', '745214', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, 0, 0, 0, 119, '2587 458785', 0),
(268, '268', 'sdfsdf', 'eterwter', NULL, 'tick007@rol.ru', NULL, '43534', '64756', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, 0, 0, 0, 119, 'tyyyyyy', 0),
(269, '269', 'Константин', 'Петров', NULL, 'karjul1183@gmail.com', NULL, '+79032009372', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(270, '270', 'Татьяна', 'Максимова', NULL, 'masy123@mail.ru', NULL, '89031009009', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, 0, 0, 0, 119, NULL, 0),
(271, '271', 'Роман', 'Поляков', NULL, '3801816@mail.ru', NULL, '8-917-545-40-11', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, 0, 0, 0, 119, NULL, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `gcm_app`
--

DROP TABLE IF EXISTS `gcm_app`;
CREATE TABLE IF NOT EXISTS `gcm_app` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `gcm_app`
--

INSERT INTO `gcm_app` (`id`, `name`, `description`) VALUES
(1, 'Гонки', NULL),
(2, 'Бег', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `gmc_achievements`
--

DROP TABLE IF EXISTS `gmc_achievements`;
CREATE TABLE IF NOT EXISTS `gmc_achievements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `ishidden` tinyint(4) NOT NULL DEFAULT '0',
  `repeatable` tinyint(4) NOT NULL DEFAULT '0',
  `point_value` float DEFAULT NULL,
  `description` text,
  `game_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Achievements' AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `gmc_achievements`
--

INSERT INTO `gmc_achievements` (`id`, `name`, `ishidden`, `repeatable`, `point_value`, `description`, `game_id`) VALUES
(1, 'collect 30 points in 1 min', 0, 0, 25, '', 1),
(2, 'run track 1 in 34.5 sec', 0, 0, 50, '', 2),
(3, 'beat 6 oponents at 2 lap', 0, 0, 50, '', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `gmc_achievement_data`
--

DROP TABLE IF EXISTS `gmc_achievement_data`;
CREATE TABLE IF NOT EXISTS `gmc_achievement_data` (
  `id` int(11) NOT NULL DEFAULT '0',
  `achievement_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `lastReportedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `completed` tinyint(4) NOT NULL DEFAULT '0',
  `percentComplete` float NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Storing achievement''s values';

-- --------------------------------------------------------

--
-- Структура таблицы `gmc_leaderboards`
--

DROP TABLE IF EXISTS `gmc_leaderboards`;
CREATE TABLE IF NOT EXISTS `gmc_leaderboards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `dataformat` varchar(255) DEFAULT NULL,
  `game_id` int(11) NOT NULL,
  `is_default` tinyint(1) DEFAULT '0',
  `parent_board` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Дамп данных таблицы `gmc_leaderboards`
--

INSERT INTO `gmc_leaderboards` (`id`, `name`, `dataformat`, `game_id`, `is_default`, `parent_board`) VALUES
(1, 'Лучшее время круга', '', 1, 0, 0),
(2, 'Лучшее время гонки', '', 1, 0, 0),
(3, 'Количество аварий', '', 1, 0, 0),
(4, 'Время круга', 'с', 2, 0, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `gmc_scores`
--

DROP TABLE IF EXISTS `gmc_scores`;
CREATE TABLE IF NOT EXISTS `gmc_scores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `leaderboard_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `score` float DEFAULT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Gamecenter scores' AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `gmc_scores`
--

INSERT INTO `gmc_scores` (`id`, `leaderboard_id`, `client_id`, `score`, `date`) VALUES
(1, 1, 1, 587, '2014-04-16 06:35:33'),
(2, 1, 2, 256, '2014-04-16 06:35:40'),
(3, 1, 3, 659, '2014-04-16 06:35:31'),
(4, 2, 1, 1254, '2014-04-16 06:35:33'),
(5, 2, 2, 542, '2014-04-16 06:51:59'),
(6, 2, 3, 4354, '2014-04-16 06:35:33');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
